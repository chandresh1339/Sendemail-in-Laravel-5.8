<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'ListingsController@index');

Auth::routes();

Route::resource('/listings','ListingsController');

Route::get('/home', 'HomeController@index')->name('home');

//This  will call the test method of Controller class
Route::get('/sendemail', 'SendEmailController@test');
Route::post('/sendemail/send', 'SendEmailController@send');
