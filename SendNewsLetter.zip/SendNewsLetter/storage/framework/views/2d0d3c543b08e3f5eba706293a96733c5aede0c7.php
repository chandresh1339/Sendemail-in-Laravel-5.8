<?php $__env->startSection('content'); ?>

    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header" align="center">Dashboard <span class="float-right"><a href="/listings/create" class="btn btn-secondary">Create News Listing</a></span>
                    <span class="float-left"><a href="/sendemail" class="btn btn-secondary">Send News Listing</a></span>
                </div>
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    
                    <h3>Your Listings</h3>

                   <?php if(count($listings)): ?>
                        <table class="table table-striped">
                            <tr>
                                
                                <th>News List</th>
                                <th></th>
                            </tr>

                            <?php $__currentLoopData = $listings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($listing->title); ?></td>
                                <td>
                                    <form class="float-right ml-2" action="/listings/<?php echo e($listing->id); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                             <button type="submit" name="Delete" class="btn btn-danger">Delete</button>
                             </form>
                             <a href="/listings/<?php echo e($listing->id); ?>/edit" class="btn btn-info float-right">Edit</a>   
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                        <?php else: ?>
                        <p>You don't have any listings yet</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\chandreshj\AppData\Roaming\Composer\LaraBiz\LaraBiz\resources\views/home.blade.php ENDPATH**/ ?>