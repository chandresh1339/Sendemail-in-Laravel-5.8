<?php $__env->startSection('content'); ?>

	    <div class="row justify-content-center">
	        <div class="col-md-8">
	            <div class="card">
	                <div class="card-header">Create News Listing<span class="float-right"><a href="/home" class="btn btn-secondary">Go Back</a></span></div>

	                <div class="card-body">
	                    <?php if(session('status')): ?>
	                        <div class="alert alert-success" role="alert">
	                            <?php echo e(session('status')); ?>

	                        </div>
	                    <?php endif; ?>
	                    <form method="post" action="/listings">
	                    <?php echo e(@csrf_field()); ?>

					               		<div class="form-group">
									    <label for="title">Enter your title</label>
									    <input type="text" class="form-control" id="title" name="title" placeholder="Enter your title">
							    	          </div>
										  <div class="form-group">
										   <label for="address">Enter the Body</label>
												    <input type="text" class="form-control" name="body" id="body"  placeholder="Enter the Body">
										  </div>
							  <!--  <div class="form-group">
									    <label for="email">Enter your email</label>
									    <input type="email" name="email" class="form-control" id="email"  placeholder="Enter your email">
							    	</div>
							    	
							    	<div class="form-group">
									    <label for="website">Enter your website</label>
									    <input type="text" name="website" class="form-control" id="website" placeholder="Enter your website">
							    	</div>
							    	 <div class="form-group">
									    <label for="phone">Enter your phone</label>
									    <input type="number" name="phone" class="form-control" id="phone" placeholder="Enter your phone">
									</div>
-->			    		

							    <!--	<div class="form-group">
									    <label for="bio">Enter your bio</label>
									    <input type="text" name="bio" class="form-control" id="bio" placeholder="Enter your bio">
							    	</div>
							    -->
							 
			 			 <button type="submit" class="btn btn-primary">Submit</button>
						</form>
	          </div>
	        </div>
	    </div>
	</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\chandreshj\AppData\Roaming\Composer\LaraBiz\LaraBiz\resources\views/create.blade.php ENDPATH**/ ?>