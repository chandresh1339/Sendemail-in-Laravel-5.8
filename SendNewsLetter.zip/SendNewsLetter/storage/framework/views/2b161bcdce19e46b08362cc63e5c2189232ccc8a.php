<?php $__env->startSection('content'); ?>

	<div class="container">
      <?php if(count($albums)>0): ?>

      <div class="row">
            <?php $__currentLoopData = $albums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $album): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     
        <div class="col-md-4">
          <div class="card mb-4 shadow-sm">
            <img src="/storage/album_covers/<?php echo e($album->cover_image); ?>" alt="<?php echo e($album->cover_image); ?>" height="200px">
            
            <div class="card-body">
              <p class="card-text"><?php echo e($album->description); ?></p>
              <div class="d-flex justify-content-between align-items-center">

                <div class="btn-group">
                  <a href="<?php echo e(route('album-show',$album->id)); ?>" class="btn btn-sm btn-outline-secondary">View</a>
<!-- AddToAny BEGIN -->
<div class="a2a_kit a2a_kit_size_32 a2a_default_style">
<a class="a2a_dd" href="https://www.addtoany.com/share"></a>
<a class="a2a_button_facebook"></a>
<a class="a2a_button_twitter"></a>
<a class="a2a_button_whatsapp"></a>
<a class="a2a_button_linkedin"></a>
</div>
<script async src="https://static.addtoany.com/menu/page.js"></script>
<!-- AddToAny END -->
             
                  <!--<button type="button" class="btn btn-sm btn-outline-secondary">Edit</button>-->
                </div>
                    <small class="text-muted"><?php echo e($album->name); ?></small>
             </div>
            </div>
          </div>

        </div>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php else: ?>
      <h3>Welcome!!! CREATE YOUR FIRST AD</h3>
      <?php endif; ?>
    </div>
		<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\chandreshj\AppData\Roaming\Composer\LaraBiz\resources\views/albums/index.blade.php ENDPATH**/ ?>