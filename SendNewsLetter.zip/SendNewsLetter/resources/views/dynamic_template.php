
<!--This will be Email BODY which customer will receive on his email-->

<p>Hi This is {{$data['name']}}</p>
<p>I have some newsletter with a message like{{$data['message']}}}} </p>

<p>Please share feedback</p>

<div >
  @if (\Session::has('success'))
   <div >
    <p>{{ \Session::get('success') }}</p>
   </div><br />
   @endif
   @if (\Session::has('failure'))
   <div >
    <p>{{ \Session::get('failure') }}</p>
   </div><br />
   @endif
   <h2>Subscribe Newsletter</h2><br/>
   <form method="post" action="{{url('newsletter')}}">
    @csrf
    </div>
    <div >
 
      <div class="container">
       <label for="Email">Email:</label>
       <input type=text name=email>
      </div>
     </div>
    <div >
     <div ></div>
     <div class="container" >
      <button type=submit name="submit" >Subscribe</button>
     </div>
    </div>
   </form>
  </div>