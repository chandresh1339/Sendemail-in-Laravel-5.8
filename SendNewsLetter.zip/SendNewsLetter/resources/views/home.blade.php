@extends('layouts.app')

@section('content')

    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header" align="center">Dashboard <span class="float-right"><a href="/listings/create" class="btn btn-secondary">Create News Listing</a></span>
                    <span class="float-left"><a href="/sendemail" class="btn btn-secondary">Send News Listing</a></span>
                </div>
                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif
                    
                    <h3>Your Listings</h3>

                   @if (count($listings))
                        <table class="table table-striped">
                            <tr>
                                
                                <th>News List</th>
                                <th></th>
                            </tr>

                            @foreach($listings as $listing)
                            <tr>
                                <td>{{$listing->title}}</td>
                                <td>
                                    <form class="float-right ml-2" action="/listings/{{$listing->id }}" method="post">
                                        @csrf
                                        @method('DELETE')
                             <button type="submit" name="Delete" class="btn btn-danger">Delete</button>
                             </form>
                             <a href="/listings/{{ $listing->id }}/edit" class="btn btn-info float-right">Edit</a>   
                            </tr>
                            @endforeach
                        </table>
                        @else
                        <p>You don't have any listings yet</p>
                    @endif
                </div>
            </div>
        </div>
    </div>
@endsection
