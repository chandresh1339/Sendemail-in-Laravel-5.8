@extends('layouts.app')

@section('content')

	    <div class="row justify-content-center">
	        <div class="col-md-8">
	            <div class="card">
	                <div class="card-header">EDIT Listing<span class="float-right"><a href="/home" class="btn btn-secondary">Go Back</a></span></div>

	                <div class="card-body">
	                    @if (session('status'))
	                        <div class="alert alert-success" role="alert">
	                            {{ session('status') }}
	                        </div>
	                    @endif
	                    <form method="post" action="/listings/{{$listing->id}}">
	                 @csrf
	                 @method('PUT')
					               		<div class="form-group">
									    <label for="name">Enter your title</label>
									    <input type="text" class="form-control" id="title"  placeholder="Enter your title" name="title"  value="{{$listing->title}}" >
							    	</div>
										  <div class="form-group">
										   <label for="address">Enter the Body</label>
												    <input type="text" class="form-control" id="body"  name="body" placeholder="Enter the body" value="{{$listing->body}}">
										  </div>
							   
			 			 <button type="submit" class="btn btn-primary">Submit</button>
						</form>
	          </div>
	        </div>
	    </div>
	</div>
@endsection

