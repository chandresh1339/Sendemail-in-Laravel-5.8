<?php

namespace LaraBiz\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;

class SendMail extends Mailable
{
    use Queueable, SerializesModels;
    public $data;
    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($data)
    {
        //
        $this->data=$data;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    
//function body to which the mail will be sent
    public function build()
    {

//This method will pull the dynamic email template from view file to send to user from dynamic variable 'data'
        return $this->from('*****')->subject('Newsletter Body')->view('dynamic_template')->with('data',$this->data);

    }


}
