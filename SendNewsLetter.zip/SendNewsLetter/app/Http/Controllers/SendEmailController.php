<?php

namespace LaraBiz\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use LaraBiz\Mail\SendMail;
use App\User;

class SendEmailController extends Controller
{
    //
    function test()
    {
    	return view('send_email');
    }

//Function which sends the email with 'name and message' to be sent
    function send(Request $request)
	{

		$user = User::get(); // fetch user's to send mails

		$this->validate($request,
			[ 'name'=>'required',
				'email'=>'required|email',
				'message'=>'required'

			]);
		//This will pull the dynamic data from view template
		$data=array(

			'name'=>$request->name,
			'message'=>$request->message
		);

//Custom Email address defined to Test which emails will be sent and $data as arguments from array
		//Mail::to('youremailaddress')->send(new SendMail($data));

		//Send email to user from database to which emails will be sent and $data as arguments from array
		Mail::to($user)->send(new SendMail($data));
//This will re-direct the previous page location
		return back()->with('success','Thank you for contacting us!');


    }
}
