<?php

namespace LaraBiz\Models;

use Illuminate\Database\Eloquent\Model;

class Listing extends Model
{
//protected $primaryKey = 'id';

   public function user()
   {
   	return $this->belongsTo('LaraBiz\User');
   }
}
